import React from 'react'

const Invoice = () => {
  return (
    <div>Invoice</div>
  )
}

export default Invoice