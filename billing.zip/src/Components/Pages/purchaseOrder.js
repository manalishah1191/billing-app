import React from 'react'

const PurchaseOrder = () => {
  return (
    <div>PurchaseOrder</div>
  )
}

export default PurchaseOrder